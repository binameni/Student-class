
package javaapplication43;

import static javaapplication43.Student.NUM_OF_TESTS;

public class UndergraduateStudent extends Student{
    
    public void computeLessonGrade(){
     
         int total = 0;
         for (int i = 0; i < NUM_OF_TESTS; i++) {
            total += test[i];
             
         }
         if (total/NUM_OF_TESTS>= 70 ) {
             lessonGrade = "pass";
         }else{
         
             lessonGrade = "No pass";
         }
     
     }
    
}
