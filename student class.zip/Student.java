
package javaapplication43;

public class Student {
    protected final static int NUM_OF_TESTS =3;
    protected String name;
    protected int[] test;
    protected String lessonGrade;

    public Student() {
        this("no name");
    }
    
    public Student(String studentName) {
        name=studentName;
        test=new int[NUM_OF_TESTS];
        lessonGrade = "****";
    }

 
    public String getLessonGrade() {
        return lessonGrade;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getTestScore(int testNumber) {
        return test[testNumber-1];
    }

    public void setTestScore(int testNumber , int testScore) {
       test[testNumber-1] = testScore;
    }
    
    public void computeLessonGrade(){}
}
