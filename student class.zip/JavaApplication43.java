package javaapplication43;

import java.util.Scanner;

public class JavaApplication43 {

    public static void main(String[] args) {
        Student [] roster = new Student[25];
        for (int i = 0; i < 25; i++) {
           if(i%2==0){
                roster[i] = new UndergraduateStudent();
                roster[i].setName("under Grad " + (i+1));
                roster[i].setTestScore(1, 65);
                roster[i].setTestScore(2, 70);
                roster[i].setTestScore(3, 80);
            }else{
                roster[i] = new GraduateStudent();
                roster[i].setName("under Grad " + (i+1));
                roster[i].setTestScore(1, 85);
                roster[i].setTestScore(2, 50);
                roster[i].setTestScore(3, 40);
           }

           }
        
        for (int i = 0; i < roster.length; i++) {
              
            roster[i].computeLessonGrade();
            System.out.println(roster[i].getName()+ " 1. " + roster[i].getTestScore(1) + " " + roster[i].getLessonGrade());
            System.out.println(roster[i].getName()+ " 2. " + roster[i].getTestScore(2) + " " + roster[i].getLessonGrade());
            System.out.println(roster[i].getName()+ " 3. " + roster[i].getTestScore(3) + " " + roster[i].getLessonGrade());
        }
        
        
    }
    
}
